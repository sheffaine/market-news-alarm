# UNI news backtest

397 scored events with price data (2024-09-18 to 2026-09-22).

All returns are UNI **minus** the ETH/BTC average, so a market-wide rally doesn't count.

Entry is conservative: +1h after forum posts, 11pm ET on the release day for SEC/CFTC/FedReg.


## Events by source

| source   |   count |
|:---------|--------:|
| FedReg   |     205 |
| UniForum |      77 |
| CFTC     |      68 |
| SEC      |      47 |


Claude said it recognized 85 of 397 events from training data (possible hindsight contamination).


## All events (n=397)


**Rank correlation, signal vs later excess return** (0 = no skill, 0.1-0.2 would be meaningful for markets):


x24h: -0.038 | x72h: +0.061 | x168h: -0.026


**By signal bucket:**

| bucket         |   n | avg x24h   | avg x72h   | avg x168h   | hit rate 72h   |
|:---------------|----:|:-----------|:-----------|:------------|:---------------|
| bearish        |   3 | -2.0%      | -2.9%      | -7.4%       | 33%            |
| neutral        | 360 | +0.1%      | +0.3%      | +0.2%       | 46%            |
| bullish        |  33 | -0.1%      | +0.6%      | -0.7%       | 42%            |
| strong bullish |   1 | -0.6%      | -4.1%      | -0.0%       | 0%             |


**Strategy: buy UNI when signal >= 5, sell 72h later** (entry at the conservative time above)

- trades: 1
- avg excess return per trade: -4.08% (vs +0.26% for all events)
- win rate: 0%
- worst trade: -4.08%


**'How much time did I still have?'** For those trades, the median excess move before you could enter was +13.39%, and the median excess move over the next 7 days was -0.05%.


> Set MODEL_CUTOFF to get an out-of-sample section free of hindsight bias.


## Strongest signals

| date       | source   |   signal |   x24h |   x72h |    x168h | title                                                                                                                                         |
|:-----------|:---------|---------:|-------:|-------:|---------:|:----------------------------------------------------------------------------------------------------------------------------------------------|
| 2025-11-10 | UniForum |   +7.200 | -0.006 | -0.041 |   -0.000 | UNIfication Proposal                                                                                                                          |
| 2026-02-18 | UniForum |   +4.020 | -0.014 | +0.047 |   +0.156 | [Temp Check] Protocol Fee Expansion: Eight More Chains and Remaining Mainnet v3 Pools                                                         |
| 2025-02-13 | UniForum |   +4.020 | +0.007 | -0.026 |   -0.074 | [Governance Proposal] Uniswap Unleashed                                                                                                       |
| 2025-05-06 | UniForum |   +3.960 | -0.029 | +0.094 |   +0.169 | [RFC] Aave�s CDP for Uniswap V4 Positions                                                                                                     |
| 2025-03-12 | UniForum |   +3.840 | -0.022 | +0.020 |   +0.057 | [Re-Temperature Check] - Activate Uniswap Protocol Governance                                                                                 |
| 2026-06-25 | UniForum |   +3.650 | +0.026 | +0.033 |   +0.071 | RFC : Tokenomics overhaul : hard-capping supply via auto burn, pivoting unification to staking distribution and staking DAO treasury reserves |
| 2025-02-13 | UniForum |   -3.420 | +0.001 | -0.023 |   -0.086 | [Governance Proposal] Uniswap Unleashed: Unichain and Uniswap v4 Liquidity Incentives                                                         |
| 2026-07-07 | UniForum |   +3.420 | +0.070 | +0.108 |   +0.128 | [Temp Check] Activate v4 Protocol Fees                                                                                                        |
| 2026-09-17 | SEC      |   +3.350 | -0.023 | -0.050 | +nan     | SEC Issues �Innovation Exemption� to Facilitate the Trading of Tokenized NMS Stock and Request for Comment                                    |
| 2025-01-21 | SEC      |   +3.060 | -0.028 | -0.080 |   -0.091 | SEC Crypto 2.0: Acting Chairman Uyeda Announces Formation of New Crypto Task Force                                                            |
| 2025-08-11 | UniForum |   -3.000 | -0.030 | -0.069 |   -0.077 | [GOVERNANCE PROPOSAL] - Establish Uniswap Governance as �DUNI,� a Wyoming DUNA                                                                |
| 2026-05-16 | UniForum |   +3.000 | +0.012 | +0.012 |   +0.016 | [Temp Check] Protocol Fee Expansion: Three More Chains                                                                                        |
| 2025-09-15 | UniForum |   +2.940 | +0.013 | +0.033 |   -0.061 | Proposal to deploy Uniswap V3 on Plasma                                                                                                       |
| 2025-08-22 | UniForum |   +2.940 | +0.023 | -0.013 |   -0.052 | [RFC] Deploying Uniswap v3 on Ronin with Co-Incentives                                                                                        |
| 2026-09-18 | UniForum |   +2.940 | -0.002 | -0.056 | +nan     | [Temp Check] Protocol Fee Expansion: Arc                                                                                                      |
