# UNI fast-reaction backtest

144 Uniswap forum posts and Snapshot votes with exact timestamps and 1-minute prices (2024-09-27 to 2026-09-23).


| source          |   count |
|:----------------|--------:|
| UniForum        |      77 |
| Snapshot-result |      34 |
| Snapshot-open   |      33 |


**'Buy' events** (Claude signal >= 3.0, bullish): **19**. All other events are used as a comparison.


> Only 19 buy events. Treat the results as a rough indication, not proof.


## Average return per trade after fees: Low-fee exchange (0.25%/side)

Rows = how many minutes after the post you buy. Columns = how long you hold.


|          | hold 30m              | hold 1h               | hold 2h               | hold 4h               | hold 24h              | hold 72h              |
|:---------|:----------------------|:----------------------|:----------------------|:----------------------|:----------------------|:----------------------|
| buy +2m  | +0.2% (53% win, n=19) | +1.1% (67% win, n=18) | +1.4% (58% win, n=19) | +1.1% (53% win, n=19) | -1.5% (47% win, n=19) | +1.7% (37% win, n=19) |
| buy +5m  | +0.1% (58% win, n=19) | +0.8% (53% win, n=19) | +1.1% (53% win, n=19) | +1.0% (37% win, n=19) | -1.8% (42% win, n=19) | +1.7% (37% win, n=19) |
| buy +15m | +0.6% (44% win, n=18) | +0.9% (53% win, n=19) | +1.4% (53% win, n=19) | +0.9% (32% win, n=19) | -1.8% (37% win, n=19) | +1.5% (47% win, n=19) |
| buy +30m | +0.4% (32% win, n=19) | +0.4% (32% win, n=19) | +0.6% (32% win, n=19) | +0.6% (37% win, n=19) | -2.6% (32% win, n=19) | +1.1% (42% win, n=19) |


## Average return per trade after fees: Wealthsimple-style (1.75%/side)

Rows = how many minutes after the post you buy. Columns = how long you hold.


|          | hold 30m             | hold 1h              | hold 2h               | hold 4h               | hold 24h              | hold 72h              |
|:---------|:---------------------|:---------------------|:----------------------|:----------------------|:----------------------|:----------------------|
| buy +2m  | -2.7% (0% win, n=19) | -1.9% (6% win, n=18) | -1.6% (11% win, n=19) | -2.0% (11% win, n=19) | -4.5% (16% win, n=19) | -1.3% (37% win, n=19) |
| buy +5m  | -2.9% (0% win, n=19) | -2.2% (5% win, n=19) | -1.9% (5% win, n=19)  | -2.0% (11% win, n=19) | -4.7% (16% win, n=19) | -1.4% (37% win, n=19) |
| buy +15m | -2.4% (6% win, n=18) | -2.1% (5% win, n=19) | -1.7% (5% win, n=19)  | -2.1% (5% win, n=19)  | -4.8% (16% win, n=19) | -1.6% (37% win, n=19) |
| buy +30m | -2.6% (5% win, n=19) | -2.6% (5% win, n=19) | -2.4% (5% win, n=19)  | -2.4% (5% win, n=19)  | -5.5% (11% win, n=19) | -1.9% (37% win, n=19) |


## Does Claude's filter help? (buy +5m, low fees)


|                         | hold 30m   | hold 1h   | hold 2h   | hold 4h   | hold 24h   | hold 72h   |   n |
|:------------------------|:-----------|:----------|:----------|:----------|:-----------|:-----------|----:|
| Claude 'buy' events     | +0.1%      | +0.8%     | +1.1%     | +1.0%     | -1.8%      | +1.7%      |  19 |
| All other events        | -0.4%      | -0.3%     | -0.3%     | -0.3%     | -0.1%      | +1.2%      | 125 |
| Every event (no filter) | -0.3%      | -0.2%     | -0.1%     | -0.2%     | -0.3%      | +1.3%      | 144 |


## How fast does the move happen?


- Median UNI move in the hour BEFORE the post: +0.09% (a big number here means the news leaked or was expected)

- Median move you'd already have missed by buying at +2 min: +0.06%

- Median move you'd already have missed by buying at +5 min: +0.20%

- Median move you'd already have missed by buying at +15 min: +0.29%

- Median move you'd already have missed by buying at +30 min: +0.71%

- For context, ETH/BTC moved +0.00% on average over the same +5m to 2h windows


## Strongest 'buy' events (low fees)


| date                |   signal | hour before   | missed by +5m   | +5m buy, hold 1h   | +5m buy, hold 2h   | +5m buy, hold 24h   | title                                                                                      |
|:--------------------|---------:|:--------------|:----------------|:-------------------|:-------------------|:--------------------|:-------------------------------------------------------------------------------------------|
| 2025-11-10 15:55 ET |     7.2  | +5.9%         | +1.4%           | +13.7%             | +23.4%             | +9.2%               | UNIfication Proposal                                                                       |
| 2025-11-17 21:01 ET |     6.09 | +1.1%         | +0.5%           | -0.6%              | -0.3%              | -0.2%               | [Vote opened] UNIfication                                                                  |
| 2025-11-22 21:01 ET |     5.88 | +0.5%         | +0.6%           | -0.5%              | +0.3%              | +1.1%               | [Vote result] UNIfication                                                                  |
| 2026-02-23 15:25 ET |     4.69 | +0.1%         | +0.1%           | +0.5%              | +0.8%              | +0.0%               | [Vote result] [Temp Check] Protocol Fee Expansion: Eight More Chains and Remaining Mainnet |
| 2026-07-12 10:41 ET |     4.48 | -0.7%         | +0.5%           | -0.1%              | -0.0%              | -4.1%               | [Vote result] [Temp Check] Activate v4 Protocol Fees                                       |
| 2025-02-25 21:06 ET |     4.2  | -0.4%         | +0.3%           | +2.1%              | +1.2%              | -3.8%               | [Vote opened] [Temp Check] Uniswap Unleashed                                               |
| 2025-02-13 22:02 ET |     4.02 | +0.3%         | -0.0%           | +0.1%              | -0.9%              | +1.0%               | [Governance Proposal] Uniswap Unleashed                                                    |
| 2026-02-18 15:25 ET |     4.02 | -0.8%         | +0.3%           | -0.1%              | -1.3%              | -1.3%               | [Vote opened] [Temp Check] Protocol Fee Expansion: Eight More Chains and Remaining Mainnet |
| 2026-02-18 15:35 ET |     4.02 | +0.8%         | +0.3%           | -1.2%              | -1.8%              | -2.1%               | [Temp Check] Protocol Fee Expansion: Eight More Chains and Remaining Mainnet v3 Pools      |
| 2025-05-06 14:36 ET |     3.96 | +0.3%         | +0.1%           | -0.1%              | -1.8%              | -1.9%               | [RFC] Aave’s CDP for Uniswap V4 Positions                                                  |
| 2025-03-02 21:06 ET |     3.84 | -1.8%         | -0.1%           | +0.3%              | +0.1%              | -15.9%              | [Vote result] [Temp Check] Uniswap Unleashed                                               |
| 2025-03-12 00:49 ET |     3.84 | -0.8%         | +0.3%           | -0.3%              | -0.9%              | -0.9%               | [Re-Temperature Check] - Activate Uniswap Protocol Governance                              |
| 2026-06-25 08:09 ET |     3.65 | +0.4%         | -0.1%           | +0.0%              | -3.4%              | -3.3%               | RFC : Tokenomics overhaul : hard-capping supply via auto burn, pivoting unification to sta |
| 2026-05-21 13:30 ET |     3.5  | +0.6%         | +0.1%           | +0.1%              | +0.2%              | +0.2%               | [Vote result] [Temp Check] Protocol Fee Expansion: Three More Chains                       |
| 2026-07-07 10:41 ET |     3.42 | -0.2%         | +0.4%           | +1.6%              | +2.8%              | +4.4%               | [Vote opened] [Temp Check] Activate v4 Protocol Fees                                       |
