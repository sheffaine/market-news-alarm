#!/usr/bin/env python3
"""
UNI news backtest
=================
Does regulatory / governance news move UNI more than the rest of crypto,
and can Claude's score tell the big ones apart ahead of time?

Pipeline (each stage caches to ./bt_data so you can re-run cheaply):
  collect  -> pull historical items from SEC, CFTC, Federal Register, Uniswap forum
  triage   -> Claude Haiku filters titles down to plausibly crypto-relevant items
  enrich   -> fetch dates + text for the survivors
  score    -> Claude scores each item WITHOUT seeing any price data
  prices   -> hourly UNI / ETH / BTC candles from Coinbase's public API
  analyze  -> excess returns vs. score, buckets, a simple strategy, report

HOW TO RUN: open this file in VS Code and press the Run button (triangle, top right).
  - First run installs the libraries it needs automatically.
  - It asks for your Anthropic API key and contact email once and remembers them
    (stored in the project root, excluded from git).
  - Results go in the bt_data folder next to this file.
  Don't type or paste anything into this file.

Optional: set MODEL_CUTOFF="YYYY-MM-DD" (see "lookahead bias" below).

Lookahead bias warning:
  Claude may already know about older events (and what prices did after) from its
  training data. The scorer is told not to use hindsight and asked to flag events it
  recognizes, and if you set MODEL_CUTOFF to the scoring model's documented training
  cutoff, the report also shows results for events AFTER that date only. Trust those
  out-of-sample numbers most.
"""

import subprocess
import sys

# ---- auto-install libraries on first run (so you can just press Run) ----
_NEEDED = {"anthropic": "anthropic", "requests": "requests", "pandas": "pandas",
           "matplotlib": "matplotlib", "tabulate": "tabulate", "tzdata": "tzdata"}
_missing = []
for _mod, _pkg in _NEEDED.items():
    try:
        __import__(_mod)
    except ImportError:
        _missing.append(_pkg)
if _missing:
    print("First run: installing", ", ".join(_missing), "(takes a minute)...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", *_missing])
    except subprocess.CalledProcessError:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "--user", *_missing])
    print("Done installing.\n")

import argparse
import bisect
import html as htmllib
import json
import os
import re
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

import requests

# ---------------------------------------------------------------- config
ET = ZoneInfo("America/New_York")
# ---- private settings (config.json and secrets live in the project root, never uploaded) ----
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent if HERE.name in ("alarm", "backtests") else HERE
CONFIG_FILE = ROOT / "config.json"


def load_contact_email() -> str:
    """The SEC asks automated readers to identify themselves with a contact email."""
    if os.environ.get("CONTACT_EMAIL"):
        return os.environ["CONTACT_EMAIL"]
    try:
        cfg = json.loads(CONFIG_FILE.read_text())
    except Exception:
        cfg = {}
    if cfg.get("contact_email"):
        return cfg["contact_email"]
    print("The SEC asks automated readers to include a contact email.")
    email = input("Your email (saved privately in config.json, not uploaded to GitHub): ").strip()
    cfg["contact_email"] = email
    CONFIG_FILE.write_text(json.dumps(cfg, indent=2))
    return email


DATA = HERE / "bt_data"
EVENTS_FILE = DATA / "events.json"
TRIAGE_MODEL = "claude-haiku-4-5-20251001"
SCORE_MODEL = "claude-sonnet-5"
EMAIL = load_contact_email()
UA = {"User-Agent": f"uni-news-backtest/1.0 ({EMAIL})"}
MODEL_CUTOFF = os.environ.get("MODEL_CUTOFF", "").strip()

FEDREG_TERMS = ["crypto", "digital asset", "tokenized", "blockchain",
                "stablecoin", "distributed ledger", "decentralized finance"]
FEDREG_AGENCIES = ["securities-and-exchange-commission",
                   "commodity-futures-trading-commission"]
COINS = {"UNI": "UNI-USD", "ETH": "ETH-USD", "BTC": "BTC-USD"}
HORIZONS = [24, 72, 168]  # hours after entry

MONTHS = {"jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6, "jul": 7,
          "aug": 8, "sep": 9, "oct": 10, "nov": 11, "dec": 12}
DATE_RE = re.compile(r"(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?\s+(\d{1,2}),\s+(\d{4})")


# ---------------------------------------------------------------- helpers
def load_events() -> dict:
    if EVENTS_FILE.exists():
        return {e["id"]: e for e in json.loads(EVENTS_FILE.read_text())}
    return {}


def save_events(events: dict) -> None:
    DATA.mkdir(exist_ok=True)
    EVENTS_FILE.write_text(json.dumps(list(events.values()), indent=1))


def get(url, params=None, pause=0.15, tries=4):
    for i in range(tries):
        try:
            r = requests.get(url, params=params, headers=UA, timeout=30)
            if r.status_code == 429 or r.status_code >= 500:
                raise requests.HTTPError(f"{r.status_code}")
            r.raise_for_status()
            time.sleep(pause)
            return r
        except Exception as e:
            wait = 2 ** i
            print(f"   ! {url[:80]} failed ({e}); retry in {wait}s")
            time.sleep(wait)
    return None


def strip_html(s: str) -> str:
    s = re.sub(r"(?is)<(script|style|noscript).*?</\1>", " ", s)
    s = re.sub(r"(?s)<[^>]+>", " ", s)
    return re.sub(r"\s+", " ", htmllib.unescape(s)).strip()


def parse_date(text: str):
    m = DATE_RE.search(text)
    if not m:
        return None
    mon, day, year = MONTHS[m.group(1)[:3].lower()], int(m.group(2)), int(m.group(3))
    try:
        return datetime(year, mon, day).date()
    except ValueError:
        return None


def iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).isoformat()


def from_iso(s: str) -> datetime:
    return datetime.fromisoformat(s.replace("Z", "+00:00"))


_client = None
def claude_json(model: str, prompt: str, max_tokens: int = 800):
    global _client
    if _client is None:
        import anthropic
        _client = anthropic.Anthropic()
    for i in range(3):
        try:
            msg = _client.messages.create(model=model, max_tokens=max_tokens,
                                          messages=[{"role": "user", "content": prompt}])
            txt = "".join(b.text for b in msg.content if b.type == "text")
            m = re.search(r"\{.*\}", txt, re.S)
            return json.loads(m.group(0))
        except Exception as e:
            print(f"   ! claude error ({e}); retrying")
            time.sleep(2 ** i)
    return None


# ---------------------------------------------------------------- 1. collect
def collect_listing(name, base, link_re, year_of, start):
    """Generic paginated listing scraper (SEC + CFTC newsrooms)."""
    items, seen = [], set()
    for page in range(300):
        r = get(base.format(page=page))
        if r is None:
            break
        links = link_re.findall(r.text)
        new, oldest = 0, 9999
        for path, raw_title, *rest in links:
            url = (base.split("/", 3)[0] + "//" + base.split("/")[2]) + path
            title = strip_html(raw_title)
            if url in seen or len(title) < 8:
                continue
            seen.add(url)
            yr = year_of(path)
            oldest = min(oldest, yr)
            if yr >= start.year:
                items.append({"id": url, "source": name, "title": title, "url": url,
                              "time_utc": None, "precise": False})
                new += 1
        print(f"   {name} page {page}: {new} new")
        if not links or oldest < start.year:
            break
    return items


def collect_sec(start):
    link_re = re.compile(r'href="(/newsroom/press-releases/\d{4}-\d+[^"#?]*)"[^>]*>(.*?)</a>', re.S)
    return collect_listing("SEC", "https://www.sec.gov/newsroom/press-releases?page={page}",
                           link_re, lambda p: int(re.search(r"/(\d{4})-\d+", p).group(1)), start)


def collect_cftc(start):
    link_re = re.compile(r'href="(/PressRoom/PressReleases/\d+-(\d{2}))"[^>]*>(.*?)</a>', re.S)
    # regex has 3 groups: path, yy, title -> reorder to (path, title)
    base = "https://www.cftc.gov/PressRoom/PressReleases?page={page}"

    class Reorder:
        def findall(self, text):
            return [(p, t) for p, _yy, t in link_re.findall(text)]
    return collect_listing("CFTC", base, Reorder(),
                           lambda p: 2000 + int(re.search(r"-(\d{2})$", p).group(1)), start)


def collect_fedreg(start, end):
    items = {}
    for agency in FEDREG_AGENCIES:
        for term in FEDREG_TERMS:
            page = 1
            while True:
                r = get("https://www.federalregister.gov/api/v1/documents.json", params={
                    "per_page": 100, "page": page, "order": "newest",
                    "conditions[term]": term,
                    "conditions[agencies][]": agency,
                    "conditions[publication_date][gte]": start.date().isoformat(),
                    "conditions[publication_date][lte]": end.date().isoformat(),
                    "fields[]": ["title", "abstract", "publication_date", "html_url", "type"],
                })
                if r is None:
                    break
                j = r.json()
                for d in j.get("results", []):
                    day = datetime.fromisoformat(d["publication_date"])
                    items[d["html_url"]] = {
                        "id": d["html_url"], "source": "FedReg", "title": d["title"],
                        "url": d["html_url"], "precise": False,
                        "time_utc": iso(day.replace(hour=12, tzinfo=ET)),
                        "text": f"{d.get('type','')}: {d['title']}. {d.get('abstract') or ''}",
                    }
                if not j.get("next_page_url"):
                    break
                page += 1
            print(f"   FedReg {agency[:12]}.. '{term}': {len(items)} total")
    return list(items.values())


def collect_forum(start):
    items = []
    for page in range(500):
        r = get("https://gov.uniswap.org/latest.json", params={"order": "created", "page": page})
        if r is None:
            break
        topics = r.json().get("topic_list", {}).get("topics", [])
        if not topics:
            break
        done = False
        for t in topics:
            created = from_iso(t["created_at"])
            if created < start:
                done = True
                continue
            url = f"https://gov.uniswap.org/t/{t['slug']}/{t['id']}"
            items.append({"id": url, "source": "UniForum", "title": t["title"], "url": url,
                          "time_utc": iso(created), "precise": True, "topic_id": t["id"]})
        print(f"   UniForum page {page}: {len(items)} total")
        if done:
            break
    return items


def stage_collect(args):
    end = datetime.now(timezone.utc)
    start = end - timedelta(days=args.days)
    events = load_events()
    if events and not args.recollect:
        print(f"already collected {len(events)} items, skipping (use --recollect to refresh)")
        return
    for name, fn in [("SEC", lambda: collect_sec(start)), ("CFTC", lambda: collect_cftc(start)),
                     ("FedReg", lambda: collect_fedreg(start, end)),
                     ("UniForum", lambda: collect_forum(start))]:
        print(f"collecting {name}...")
        try:
            for it in fn():
                events.setdefault(it["id"], it)
        except Exception as e:
            print(f"   !! {name} collector failed: {e} (site layout may have changed)")
        save_events(events)
    print(f"collected {len(events)} items total")


# ---------------------------------------------------------------- 2. triage
def stage_triage(args):
    events = load_events()
    todo = [e for e in events.values() if "relevant" not in e]
    print(f"triaging {len(todo)} titles...")
    for i in range(0, len(todo), 40):
        batch = todo[i:i + 40]
        lines = "\n".join(f"{k}. [{e['source']}] {e['title']}" for k, e in enumerate(batch))
        res = claude_json(TRIAGE_MODEL, f"""Below are titles of regulatory announcements and
Uniswap governance forum posts. Which ones could plausibly affect crypto markets, DeFi,
decentralized exchanges, or the UNI token? Be inclusive: include crypto enforcement,
tokenization, stablecoins, crypto ETFs, market-structure rules, and any Uniswap proposal
touching fees, treasury, tokenomics, or major protocol changes. Exclude routine items.

{lines}

Reply with ONLY JSON: {{"relevant": [list of numbers]}}""", max_tokens=400)
        keep = set((res or {}).get("relevant", []))
        for k, e in enumerate(batch):
            events[e["id"]]["relevant"] = k in keep
        save_events(events)
        print(f"   {min(i + 40, len(todo))}/{len(todo)}")
    print(f"relevant: {sum(e.get('relevant', False) for e in events.values())}")


# ---------------------------------------------------------------- 3. enrich
def stage_enrich(args):
    events = load_events()
    todo = [e for e in events.values() if e.get("relevant") and not e.get("text")]
    print(f"fetching text/dates for {len(todo)} items...")
    for e in todo:
        if e["source"] == "UniForum":
            r = get(f"https://gov.uniswap.org/t/{e['topic_id']}.json")
            if r:
                posts = r.json().get("post_stream", {}).get("posts", [])
                e["text"] = strip_html(posts[0]["cooked"])[:15000] if posts else e["title"]
        else:
            r = get(e["url"])
            if not r:
                continue
            text = strip_html(r.text)
            if e["source"] == "SEC":
                m = re.search(r"Washington D\.C\.,\s*(.{0,25}\d{4})", text)
                day = parse_date(m.group(1)) if m else parse_date(text)
                cut = text.find("For Immediate Release")
                text = text[cut:] if cut >= 0 else text
            else:
                day = parse_date(text)
            if day and not e.get("time_utc"):
                e["time_utc"] = iso(datetime(day.year, day.month, day.day, 12, tzinfo=ET))
            e["text"] = text[:15000]
        save_events(events)
    missing = sum(1 for e in events.values() if e.get("relevant") and not e.get("time_utc"))
    if missing:
        print(f"   note: {missing} relevant items have no date and will be skipped")


# ---------------------------------------------------------------- 4. score
SCORE_PROMPT = """You are scoring a news item for a crypto trader, as of the moment it was
published. Use ONLY the document below and what was publicly known BEFORE {date}.
Do NOT use any knowledge of later events or of how prices moved afterwards.

SOURCE: {source}
DATE: {date}
TITLE: {title}
TEXT: {text}

Reply with ONLY JSON:
{{"relevance": <0-10, how directly this affects the UNI token specifically>,
  "direction": <-1 bearish for UNI, 0 unclear/neutral, 1 bullish for UNI>,
  "impact": <1-10, how big a deal this is for DEX tokens if it plays out>,
  "surprise": <1-10, how unexpected this was given what was public before>,
  "confidence": <1-10, confidence in your own read>,
  "recognizes_event": <true if you recognize this specific event from training data>,
  "reasoning": "<2 sentences>"}}"""


def signal_of(s: dict) -> float:
    """Signed signal, roughly -10..10. Kept deliberately simple and visible."""
    raw = 0.4 * s["impact"] + 0.3 * s["surprise"] + 0.3 * s["relevance"]
    return round(s["direction"] * raw * s["confidence"] / 10, 2)


def stage_score(args):
    events = load_events()
    todo = [e for e in events.values() if e.get("relevant") and e.get("time_utc") and "score" not in e]
    print(f"scoring {len(todo)} items with {SCORE_MODEL}...")
    for n, e in enumerate(todo, 1):
        date = from_iso(e["time_utc"]).astimezone(ET).strftime("%Y-%m-%d")
        s = claude_json(SCORE_MODEL, SCORE_PROMPT.format(
            source=e["source"], date=date, title=e["title"], text=e.get("text", e["title"])[:12000]), max_tokens=1200)
        try:
            s = {k: s[k] for k in ["relevance", "direction", "impact", "surprise",
                                   "confidence", "recognizes_event", "reasoning"]}
            s["signal"] = signal_of(s)
            e["score"] = s
        except Exception:
            print(f"   ! could not score: {e['title'][:60]}")
        save_events(events)
        if n % 10 == 0:
            print(f"   {n}/{len(todo)}")


# ---------------------------------------------------------------- 5. prices
def price_file(sym):
    return DATA / f"prices_{sym}.json"


def _fetch_range(product, have, a, b):
    """Fetch hourly candles for [a, b) in 300-candle chunks into dict `have`."""
    cur, failed = a, 0
    while cur < b:
        nxt = min(cur + timedelta(hours=300), b)
        r = get(f"https://api.exchange.coinbase.com/products/{product}/candles",
                params={"granularity": 3600, "start": cur.isoformat(), "end": nxt.isoformat()},
                pause=0.25)
        if r is None:
            failed += 1
        else:
            for t, _lo, _hi, _op, close, _vol in r.json():
                have[int(t)] = float(close)
        cur = nxt
    return failed


def _gaps(times, start_ts, end_ts, max_gap=6 * 3600):
    """Return (a, b) ranges with no candles for longer than max_gap."""
    pts = [start_ts] + sorted(t for t in times if start_ts <= t <= end_ts) + [end_ts]
    return [(pts[i], pts[i + 1]) for i in range(len(pts) - 1) if pts[i + 1] - pts[i] > max_gap]


def stage_prices(args):
    end = datetime.now(timezone.utc).replace(minute=0, second=0, microsecond=0)
    start = end - timedelta(days=args.days + 10)
    total_failed = 0
    for sym, product in COINS.items():
        f = price_file(sym)
        have = {int(t): c for t, c in json.loads(f.read_text())} if f.exists() else {}
        holes = _gaps(have.keys(), int(start.timestamp()), int(end.timestamp()))
        print(f"prices {sym}: {len(have)} candles on file, {len(holes)} gap(s) to fill...")
        for a, b in holes:
            total_failed += _fetch_range(product, have,
                                         datetime.fromtimestamp(a, timezone.utc),
                                         datetime.fromtimestamp(b, timezone.utc))
            f.write_text(json.dumps(sorted(have.items())))  # save progress as we go
        left = _gaps(have.keys(), int(start.timestamp()), int(end.timestamp()))
        print(f"   {len(have)} hourly candles, {len(left)} gap(s) remaining")
    if total_failed:
        print("\n!! Some price downloads failed (internet dropped?). Just press Run again;")
        print("   it will only re-download the missing pieces.")


class Series:
    def __init__(self, sym):
        rows = json.loads(price_file(sym).read_text())
        self.t = [int(t) for t, _ in rows]
        self.c = [float(c) for _, c in rows]

    def at(self, dt: datetime):
        """Close of the last candle at or before dt (None if outside data)."""
        ts = dt.timestamp()
        if not self.t or ts < self.t[0] or ts > self.t[-1] + 3600:
            return None
        i = bisect.bisect_right(self.t, ts) - 1
        if i < 0 or ts - self.t[i] > 6 * 3600:
            return None  # hole in the data: skip rather than use a stale price
        return self.c[i]


# ---------------------------------------------------------------- 6. analyze
def event_windows(e):
    """
    Precise timestamps (forum posts): baseline = post time, entry = +1h.
    Date-only (SEC/CFTC/FedReg): baseline = start of that day ET, entry = 11pm ET
    that day -- i.e. 'you only heard about it that evening'. Deliberately conservative.
    """
    t = from_iso(e["time_utc"])
    if e["precise"]:
        return t, t + timedelta(hours=1)
    d = t.astimezone(ET)
    base = datetime(d.year, d.month, d.day, 0, tzinfo=ET)
    return base, base + timedelta(hours=23)


def stage_analyze(args):
    import pandas as pd

    events = [e for e in load_events().values() if e.get("score")]
    if not events:
        sys.exit("no scored events yet: run collect/triage/enrich/score first")
    px = {s: Series(s) for s in COINS}

    rows = []
    for e in events:
        base, entry = event_windows(e)
        row = {"date": base.astimezone(ET).strftime("%Y-%m-%d"), "source": e["source"],
               "title": e["title"], "url": e["url"], **{k: e["score"][k] for k in
               ["signal", "direction", "impact", "surprise", "relevance", "confidence",
                "recognizes_event"]}}
        def excess(t0, t1):
            """UNI return minus avg(ETH, BTC) return between t0 and t1."""
            r = {}
            for s in COINS:
                a, b = px[s].at(t0), px[s].at(t1)
                if a is None or b is None:
                    return None
                r[s] = b / a - 1
            return r["UNI"] - (r["ETH"] + r["BTC"]) / 2

        row["pre_entry_excess"] = excess(base, entry)
        if row["pre_entry_excess"] is None:
            continue
        for h in HORIZONS:
            row[f"x{h}h"] = excess(entry, entry + timedelta(hours=h))
        rows.append(row)

    df = pd.DataFrame(rows).sort_values("date")
    DATA.mkdir(exist_ok=True)
    df.to_csv(DATA / "events_scored.csv", index=False)

    out = []
    P = out.append
    thr = args.threshold
    P(f"# UNI news backtest\n\n{len(df)} scored events with price data "
      f"({df['date'].min()} to {df['date'].max()}).\n")
    P("All returns are UNI **minus** the ETH/BTC average, so a market-wide rally doesn't count.\n")
    P("Entry is conservative: +1h after forum posts, 11pm ET on the release day for SEC/CFTC/FedReg.\n")
    P("\n## Events by source\n\n" + df["source"].value_counts().to_markdown() + "\n")
    rec = int(df["recognizes_event"].fillna(False).astype(bool).sum())
    P(f"\nClaude said it recognized {rec} of {len(df)} events from training data "
      "(possible hindsight contamination).\n")

    def section(d, label):
        P(f"\n## {label} (n={len(d)})\n")
        if len(d) < 30:
            P(f"\n> Only {len(d)} events: treat everything below as anecdotal.\n")
        cols = [f"x{h}h" for h in HORIZONS]
        def spearman(a, b):
            m = a.notna() & b.notna()
            if m.sum() < 3:
                return float("nan")
            return a[m].rank().corr(b[m].rank())  # rank correlation, no scipy needed
        corr = {c: spearman(d["signal"], d[c]) for c in cols}
        P("\n**Rank correlation, signal vs later excess return** (0 = no skill, "
          "0.1-0.2 would be meaningful for markets):\n\n")
        P(" | ".join(f"{c}: {v:+.3f}" for c, v in corr.items()) + "\n")

        bins = [-99, -5, -2, 2, 5, 99]
        labels = ["strong bearish", "bearish", "neutral", "bullish", "strong bullish"]
        d = d.assign(bucket=pd.cut(d["signal"], bins=bins, labels=labels))
        g = d.groupby("bucket", observed=True)
        tab = pd.DataFrame({
            "n": g.size(),
            **{f"avg {c}": g[c].mean().map(lambda v: f"{v:+.1%}") for c in cols},
            "hit rate 72h": g["x72h"].apply(lambda s: f"{(s > 0).mean():.0%}"),
        })
        P("\n**By signal bucket:**\n\n" + tab.to_markdown() + "\n")

        longs = d[d["signal"] >= thr].dropna(subset=["x72h"])
        base = d.dropna(subset=["x72h"])
        if len(longs):
            P(f"\n**Strategy: buy UNI when signal >= {thr}, sell 72h later** "
              f"(entry at the conservative time above)\n\n"
              f"- trades: {len(longs)}\n"
              f"- avg excess return per trade: {longs['x72h'].mean():+.2%} "
              f"(vs {base['x72h'].mean():+.2%} for all events)\n"
              f"- win rate: {(longs['x72h'] > 0).mean():.0%}\n"
              f"- worst trade: {longs['x72h'].min():+.2%}\n")
            P(f"\n**'How much time did I still have?'** For those trades, the median excess "
              f"move before you could enter was {longs['pre_entry_excess'].median():+.2%}, and "
              f"the median excess move over the next 7 days was {longs['x168h'].median():+.2%}.\n")
        else:
            P(f"\nNo events reached signal >= {thr}.\n")

    section(df, "All events")
    if MODEL_CUTOFF:
        section(df[df["date"] > MODEL_CUTOFF], f"Out-of-sample: after model cutoff {MODEL_CUTOFF}")
    else:
        P("\n> Set MODEL_CUTOFF to get an out-of-sample section free of hindsight bias.\n")

    top = df.reindex(df["signal"].abs().sort_values(ascending=False).index).head(15)
    P("\n## Strongest signals\n\n" + top[["date", "source", "signal", "x24h", "x72h", "x168h", "title"]]
      .to_markdown(index=False, floatfmt="+.3f") + "\n")

    report = "\n".join(out)
    (DATA / "report.md").write_text(report)
    print(report)

    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        d = df.dropna(subset=["x72h"])
        fig, ax = plt.subplots(figsize=(8, 5))
        colors = {"SEC": "tab:blue", "CFTC": "tab:orange", "FedReg": "tab:green", "UniForum": "tab:pink"}
        for src, g in d.groupby("source"):
            ax.scatter(g["signal"], g["x72h"] * 100, label=src, alpha=0.7, c=colors.get(src, "gray"))
        ax.axhline(0, color="gray", lw=0.8)
        ax.axvline(0, color="gray", lw=0.8)
        ax.set_xlabel("Claude signal (before seeing prices)")
        ax.set_ylabel("UNI excess return, 72h after entry (%)")
        ax.set_title("Does the score predict the move?")
        ax.legend()
        fig.tight_layout()
        fig.savefig(DATA / "signal_vs_return.png", dpi=130)
        print(f"\nsaved {DATA/'report.md'}, {DATA/'events_scored.csv'}, {DATA/'signal_vs_return.png'}")
    except Exception as e:
        print(f"(chart skipped: {e})")


# ---------------------------------------------------------------- main
STAGES = {"collect": stage_collect, "triage": stage_triage, "enrich": stage_enrich,
          "score": stage_score, "prices": stage_prices, "analyze": stage_analyze}

KEY_FILE = ROOT / "anthropic_key.txt"


def ensure_api_key():
    if os.environ.get("ANTHROPIC_API_KEY"):
        return
    if KEY_FILE.exists() and KEY_FILE.read_text().strip():
        os.environ["ANTHROPIC_API_KEY"] = KEY_FILE.read_text().strip()
        return
    print("Paste your Anthropic API key (starts with sk-ant-) and press Enter.")
    print("Get one at https://console.anthropic.com -> API Keys.")
    key = input("API key: ").strip().strip('"')
    if not key.startswith("sk-ant-"):
        sys.exit("That doesn't look like an API key. Run again and paste the full key.")
    KEY_FILE.write_text(key)
    print(f"Saved to {KEY_FILE.name} so you won't be asked again (keep that file private).\n")
    os.environ["ANTHROPIC_API_KEY"] = key


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("stage", nargs="?", default="all", choices=[*STAGES, "all"])
    ap.add_argument("--days", type=int, default=730, help="how far back to go (default 2 years)")
    ap.add_argument("--recollect", action="store_true", help="re-scrape news sources even if already collected")
    ap.add_argument("--threshold", type=float, default=5, help="signal needed to 'buy' in the strategy test")
    a = ap.parse_args()
    DATA.mkdir(exist_ok=True)
    if a.stage in ("all", "triage", "score"):
        ensure_api_key()
    print(f"Results will be saved in: {DATA}")
    for name in (STAGES if a.stage == "all" else [a.stage]):
        print(f"\n=== {name} ===")
        STAGES[name](a)
    print(f"\nALL DONE. Open {DATA / 'report.md'} and send it to Claude.")
