#!/usr/bin/env python3
"""
UNI FAST backtest: "What if I bought within minutes of the news?"
=================================================================

HOW TO RUN: put this file in the SAME folder as uni_news_backtest.py and the
bt_data folder, open it in VS Code, and press Run. Don't type into this file.

What it does:
  1. Adds Uniswap Snapshot votes (vote opened + vote result) to the forum posts
     you already have. Both have exact timestamps, so minute-level timing is honest.
  2. Has Claude score the new items (same prompt as before, no price data shown).
  3. Downloads 1-minute UNI/ETH/BTC prices around every event (Coinbase, free).
  4. Simulates buying UNI 2, 5, 15 or 30 minutes after each post, selling after
     30 min, 1h, 2h, 4h, 24h or 72h, and subtracts trading fees:
       - Wealthsimple-style fee: ~1.75% per side (check their current pricing)
       - Low-fee exchange:       ~0.25% per side
  5. Writes bt_data/fast_report.md

SEC releases are NOT included: they only carry a date, not an exact time.

Entry prices are conservative: "buy at +5 min" uses the opening price of the first
1-minute candle that starts at or after +5 min, never a price from before that.
"""

import bisect
import importlib.util
import json
import os
import sys
from argparse import Namespace
from datetime import datetime, timedelta, timezone
from pathlib import Path

# ---- find the main script, even if Windows saved extra copies like "uni_news_backtest (2).py"
HERE = Path(__file__).resolve().parent
if HERE.name == "bt_data":          # tolerate this file being placed inside bt_data
    HERE = HERE.parent
os.chdir(HERE)
_copies = sorted(list(HERE.glob("uni_news_backtest*.py")) + list((HERE / "bt_data").glob("uni_news_backtest*.py")),
                 key=lambda p: p.stat().st_mtime, reverse=True)
if not _copies:
    raise SystemExit(f"Can't find uni_news_backtest.py in {HERE}. Put both scripts in the same folder.")
_spec = importlib.util.spec_from_file_location("uni_news_backtest", _copies[0])
base = importlib.util.module_from_spec(_spec)
sys.modules["uni_news_backtest"] = base
_spec.loader.exec_module(base)      # also auto-installs libraries on first run
if not hasattr(base, "_gaps"):
    raise SystemExit(f"{_copies[0].name} is an old version. Download the latest uni_news_backtest.py "
                     "from the chat and put it in this folder.")
# always use the bt_data folder next to the scripts
base.DATA = HERE / "bt_data"
base.EVENTS_FILE = base.DATA / "events.json"
print(f"Using {_copies[0].name} and data in {base.DATA}")

import requests

DATA = base.DATA
MIN_FILE = DATA / "prices_1m.json"
SNAPSHOT_SPACE = "uniswapgovernance.eth"
DAYS = 730
THRESHOLD = 3.0  # Claude signal needed to count as "buy" news
FEES = {"Low-fee exchange (0.25%/side)": 0.0025,
        "Wealthsimple-style (1.75%/side)": 0.0175}
ENTRY_MIN = [2, 5, 15, 30]
EXITS = [("30m", 30), ("1h", 60), ("2h", 120), ("4h", 240), ("24h", 1440), ("72h", 4320)]
FAST_SOURCES = {"UniForum", "Snapshot-open", "Snapshot-result"}


# ------------------------------------------------------------ 1. Snapshot
def collect_snapshot():
    events = base.load_events()
    start = int((datetime.now(timezone.utc) - timedelta(days=DAYS)).timestamp())
    now = datetime.now(timezone.utc).timestamp()
    q = """query($skip:Int,$start:Int){ proposals(first:100, skip:$skip,
      where:{space:"%s", created_gte:$start}, orderBy:"created", orderDirection:desc)
      { id title body created end state choices scores scores_total } }""" % SNAPSHOT_SPACE
    skip, added = 0, 0
    while True:
        try:
            r = requests.post("https://hub.snapshot.org/graphql", headers=base.UA, timeout=30,
                              json={"query": q, "variables": {"skip": skip, "start": start}})
            props = r.json()["data"]["proposals"]
        except Exception as e:
            print(f"   ! Snapshot request failed ({e}); continuing with what we have")
            break
        if not props:
            break
        for p in props:
            url = f"https://snapshot.org/#/{SNAPSHOT_SPACE}/proposal/{p['id']}"
            opened = url + "#open"
            if opened not in events:
                events[opened] = {
                    "id": opened, "source": "Snapshot-open", "url": url, "precise": True,
                    "title": f"[Vote opened] {p['title']}",
                    "time_utc": base.iso(datetime.fromtimestamp(p["created"], timezone.utc)),
                    "text": (p.get("body") or p["title"])[:12000]}
                added += 1
            result = url + "#result"
            if p.get("end") and p["end"] < now and p.get("scores") and result not in events:
                tally = ", ".join(f"{c}: {s:,.0f}" for c, s in zip(p["choices"], p["scores"]))
                events[result] = {
                    "id": result, "source": "Snapshot-result", "url": url, "precise": True,
                    "title": f"[Vote result] {p['title']}",
                    "time_utc": base.iso(datetime.fromtimestamp(p["end"], timezone.utc)),
                    "text": f"VOTE CLOSED. Result: {tally} (total {p.get('scores_total', 0):,.0f} UNI).\n\n"
                            f"Proposal: {(p.get('body') or '')[:10000]}"}
                added += 1
        skip += 100
    base.save_events(events)
    print(f"Snapshot: added {added} new items")


# ------------------------------------------------------------ 2. 1-minute prices
def fetch_minutes():
    store = json.loads(MIN_FILE.read_text()) if MIN_FILE.exists() else {}
    for s in base.COINS:
        store.setdefault(s, {})
    done = set(store.get("_windows", []))
    evs = [e for e in base.load_events().values()
           if e.get("source") in FAST_SOURCES and e.get("score") and e.get("time_utc")]
    todo = []
    for e in evs:
        a = base.from_iso(e["time_utc"]).replace(second=0, microsecond=0) - timedelta(minutes=60)
        if str(int(a.timestamp())) not in done:
            todo.append(a)
    print(f"1-minute prices: {len(todo)} event windows to download ({len(evs) - len(todo)} cached)")
    for n, a in enumerate(todo, 1):
        b = a + timedelta(minutes=299)  # Coinbase max 300 candles per request
        ok = True
        for sym, product in base.COINS.items():
            r = base.get(f"https://api.exchange.coinbase.com/products/{product}/candles",
                         params={"granularity": 60, "start": a.isoformat(), "end": b.isoformat()},
                         pause=0.2)
            if r is None:
                ok = False
                continue
            for t, _lo, _hi, op, cl, _v in r.json():
                store[sym][str(int(t))] = [float(op), float(cl)]
        if ok:
            done.add(str(int(a.timestamp())))
        if n % 10 == 0 or n == len(todo):
            store["_windows"] = sorted(done)
            MIN_FILE.write_text(json.dumps(store))
            print(f"   {n}/{len(todo)}")
    store["_windows"] = sorted(done)
    MIN_FILE.write_text(json.dumps(store))


class Minutes:
    def __init__(self, d):
        rows = sorted((int(k), v) for k, v in d.items())
        self.t = [t for t, _ in rows]
        self.o = [v[0] for _, v in rows]
        self.c = [v[1] for _, v in rows]

    def at_or_after(self, dt, max_wait=300):
        """Open of first candle starting at/after dt (conservative entry/exit price)."""
        ts = dt.timestamp()
        i = bisect.bisect_left(self.t, ts)
        if i < len(self.t) and self.t[i] - ts <= max_wait:
            return self.o[i]
        return None

    def before(self, dt, max_age=600):
        """Close of last candle that finished before dt."""
        ts = dt.timestamp() - 60
        i = bisect.bisect_right(self.t, ts) - 1
        if i >= 0 and ts - self.t[i] <= max_age:
            return self.c[i]
        return None


# ------------------------------------------------------------ 3. analysis
def analyze():
    import pandas as pd

    if not MIN_FILE.exists():
        raise SystemExit("no 1-minute price data yet")
    raw = json.loads(MIN_FILE.read_text())
    mins = {s: Minutes(raw.get(s, {})) for s in base.COINS}
    hours = {s: base.Series(s) for s in base.COINS}

    def price(sym, dt, minutes_after_post):
        # minute data covers roughly -60..+239 min around the post; beyond that use hourly
        if minutes_after_post < 235:
            return mins[sym].at_or_after(dt)
        return hours[sym].at(dt)

    rows = []
    for e in base.load_events().values():
        if e.get("source") not in FAST_SOURCES or not e.get("score") or not e.get("time_utc"):
            continue
        post = base.from_iso(e["time_utc"])
        p_post = mins["UNI"].at_or_after(post)
        p_before = mins["UNI"].before(post - timedelta(minutes=55))
        p_at = mins["UNI"].before(post)
        if p_post is None:
            continue
        row = {"date": post.astimezone(base.ET).strftime("%Y-%m-%d %H:%M ET"),
               "source": e["source"], "title": e["title"][:90],
               "signal": e["score"]["signal"], "direction": e["score"]["direction"],
               "hour_before_post": (p_at / p_before - 1) if p_at and p_before else None}
        for d in ENTRY_MIN:
            entry_t = post + timedelta(minutes=d)
            pe = mins["UNI"].at_or_after(entry_t)
            row[f"missed_{d}m"] = (pe / p_post - 1) if pe else None
            for name, h in EXITS:
                exit_t = entry_t + timedelta(minutes=h)
                px = price("UNI", exit_t, d + h)
                if pe is None or px is None:
                    row[f"g_{d}_{name}"] = None
                    continue
                row[f"g_{d}_{name}"] = px / pe  # gross price ratio
                # market move over same window (avg ETH/BTC) for context
                mk = []
                for s in ("ETH", "BTC"):
                    a, b = price(s, entry_t, d), price(s, exit_t, d + h)
                    if a and b:
                        mk.append(b / a - 1)
                row[f"mkt_{d}_{name}"] = sum(mk) / len(mk) if mk else None
        rows.append(row)

    if not rows:
        raise SystemExit("no events with 1-minute price data")
    df = pd.DataFrame(rows).sort_values("date")
    df.to_csv(DATA / "fast_events.csv", index=False)

    def net(g, fee):
        return (1 - fee) ** 2 * g - 1

    out = []
    P = out.append
    P("# UNI fast-reaction backtest\n")
    P(f"{len(df)} Uniswap forum posts and Snapshot votes with exact timestamps and 1-minute prices "
      f"({df['date'].min()[:10]} to {df['date'].max()[:10]}).\n")
    P("\n" + df["source"].value_counts().to_markdown() + "\n")

    buys = df[(df["signal"] >= THRESHOLD) & (df["direction"] == 1)]
    P(f"\n**'Buy' events** (Claude signal >= {THRESHOLD}, bullish): **{len(buys)}**. "
      f"All other events are used as a comparison.\n")
    if len(buys) < 30:
        P(f"\n> Only {len(buys)} buy events. Treat the results as a rough indication, not proof.\n")

    for label, fee in FEES.items():
        P(f"\n## Average return per trade after fees: {label}\n")
        P("Rows = how many minutes after the post you buy. Columns = how long you hold.\n\n")
        tab = {}
        for d in ENTRY_MIN:
            tab[f"buy +{d}m"] = {}
            for name, _ in EXITS:
                col = buys[f"g_{d}_{name}"].dropna()
                if len(col):
                    r = net(col, fee)
                    tab[f"buy +{d}m"][f"hold {name}"] = f"{r.mean():+.1%} ({(r > 0).mean():.0%} win, n={len(r)})"
                else:
                    tab[f"buy +{d}m"][f"hold {name}"] = "-"
        P(pd.DataFrame(tab).T.to_markdown() + "\n")

    low = list(FEES.values())[0]
    P("\n## Does Claude's filter help? (buy +5m, low fees)\n\n")
    cmp_rows = {}
    for lab, sub in [("Claude 'buy' events", buys),
                     ("All other events", df.drop(buys.index)),
                     ("Every event (no filter)", df)]:
        cmp_rows[lab] = {f"hold {name}": (f"{net(sub[f'g_5_{name}'].dropna(), low).mean():+.1%}"
                                          if sub[f"g_5_{name}"].notna().any() else "-")
                         for name, _ in EXITS}
        cmp_rows[lab]["n"] = len(sub)
    P(pd.DataFrame(cmp_rows).T.to_markdown() + "\n")

    if len(buys):
        P("\n## How fast does the move happen?\n\n")
        P(f"- Median UNI move in the hour BEFORE the post: {buys['hour_before_post'].median():+.2%} "
          "(a big number here means the news leaked or was expected)\n")
        for d in ENTRY_MIN:
            P(f"- Median move you'd already have missed by buying at +{d} min: "
              f"{buys[f'missed_{d}m'].median():+.2%}\n")
        mk = buys["mkt_5_2h"].dropna()
        if len(mk):
            P(f"- For context, ETH/BTC moved {mk.mean():+.2%} on average over the same +5m to 2h windows\n")

        show = buys.sort_values("signal", ascending=False).head(15).copy()
        for name in ["1h", "2h", "24h"]:
            show[f"+5m buy, hold {name}"] = net(show[f"g_5_{name}"], low).map(
                lambda v: f"{v:+.1%}" if pd.notna(v) else "-")
        show["hour before"] = show["hour_before_post"].map(lambda v: f"{v:+.1%}" if pd.notna(v) else "-")
        show["missed by +5m"] = show["missed_5m"].map(lambda v: f"{v:+.1%}" if pd.notna(v) else "-")
        P("\n## Strongest 'buy' events (low fees)\n\n")
        P(show[["date", "signal", "hour before", "missed by +5m", "+5m buy, hold 1h",
                "+5m buy, hold 2h", "+5m buy, hold 24h", "title"]].to_markdown(index=False) + "\n")

    report = "\n".join(out)
    (DATA / "fast_report.md").write_text(report, encoding="utf-8")
    print(report)
    print(f"\nALL DONE. Open {DATA / 'fast_report.md'} and send it to Claude.")


# ------------------------------------------------------------ main
if __name__ == "__main__":
    if not base.EVENTS_FILE.exists():
        raise SystemExit("Can't find bt_data/events.json. Put this file in the same folder "
                         "as uni_news_backtest.py and the bt_data folder.")
    base.ensure_api_key()
    args = Namespace(days=DAYS, recollect=False, threshold=THRESHOLD)
    print(f"Using data folder: {DATA}\n")
    print("=== Snapshot votes ===");      collect_snapshot()
    print("\n=== triage new items ===");  base.stage_triage(args)
    print("\n=== score new items ===");   base.stage_score(args)
    print("\n=== hourly prices ===");     base.stage_prices(args)
    print("\n=== 1-minute prices ===");   fetch_minutes()
    print("\n=== analysis ===");          analyze()
