# Market News Alarm 🚨

**An AI agent that reads government, financial and crypto news 24/7, rates how much market volatility each item could cause, and pushes an alert to my phone when the rating is above 7/10.**

Before building the live alarm, I backtested the idea on two years of real news and price data. The results changed what I built.

<p align="center"><img src="docs/images/phone_alert.png" width="380" alt="Example alert on phone"></p>

---

## The story

**Hypothesis.** On Sept 17, 2026 the SEC issued an "innovation exemption" for trading tokenized stocks, and UNI (Uniswap's token) rose ~38% that week. The weekly chart made it look like there was plenty of time to act. Could an agent that reads regulatory news and scores it catch moves like this?

**Test 1: does a smart, end-of-day read of the news predict the move?**
I collected ~400 items from the SEC, CFTC, Federal Register and the Uniswap governance forum, had Claude score each one *without seeing prices*, and measured UNI's move afterwards **relative to ETH/BTC** (so market-wide rallies don't count).

- Result: **no predictive skill.** Rank correlation between score and later excess return was about zero at every horizon (−0.04, +0.06, −0.03 at 24h / 72h / 7d).
- The hourly data showed why: for the Sept 17 case, most of the move happened *before or during* the release day, not in the days after.

![Sept 17 case study](docs/images/sept17_sec_case_study.png)

**Test 2: what if the agent reacts within minutes?**
I re-ran the test on 144 Uniswap forum posts and governance votes (which have exact timestamps), using 1-minute prices, simulated entries at +2/+5/+15/+30 minutes, several holding periods, and two fee levels.

- With low fees (0.25%/side), buying 2 minutes after Claude-flagged posts and holding 2 hours averaged **+1.4%** per trade. **Excluding one event, that drops to ~+0.1%.**
- With typical retail-app fees (~1.75%/side), **every** entry/hold combination lost money.
- The one event that paid was the UNIfication fee-switch proposal: an alert-speed buy at +5 minutes was up ~23% two hours later.

![UNIfication minute chart](docs/images/unification_minute_chart.png)

**Conclusion → design pivot.** Routine news doesn't produce a tradeable edge after fees, fast or slow. What matters is rare, high-impact, genuinely new news, caught within minutes. So the live system is an **alarm for rare events with a high threshold**, not a trading bot, and every alert says "volatility, not a buy signal."

---

## How the live alarm works

```mermaid
flowchart LR
    A["8 news sources<br/>SEC · CFTC · Federal Reserve · Federal Register<br/>CNBC · Yahoo Finance · CoinDesk · Cointelegraph"] -->|"poll every 60s"| B["New-item filter<br/>(seen-state on disk)"]
    B --> C["Claude Haiku<br/>quick 1–10 triage<br/>batches of 30 headlines"]
    C -->|"score ≥ 6"| D["Claude Sonnet<br/>full read of the article:<br/>score, markets affected,<br/>novelty, duplicate check"]
    D -->|"score > 7 and not a duplicate"| E["ntfy push notification<br/>to phone"]
    C --> F[("news_log.csv<br/>every item, timestamped")]
    D --> F
```

**Design decisions**

| Decision | Why |
|---|---|
| Two-tier models (Haiku → Sonnet) | Cheap model screens hundreds of headlines a day; the expensive model only reads the few that might matter. Keeps cost to a few dollars a month. |
| Score the *new information*, not the topic | The prompt anchors the 1–10 scale with examples and lowers scores for scheduled, expected or already-reported news, the main lesson from the backtests. |
| Duplicate suppression | Recent alerts are passed to the model so the same story from SEC.gov and CNBC doesn't alert twice. |
| Seed "seen" items on first run | Prevents a flood of alerts for old news at startup. |
| Fail-soft sources | One broken feed doesn't stop the others; failures are reported once, then retried quietly. |
| Hourly cap on full reads | Hard ceiling on API spend if a news flood hits. |
| Log every rated item with timestamps | Builds a clean dataset to evaluate the live alerts later (SEC pages only expose dates, so exact timestamps had to be captured live). |

## Backtest methodology

- **Excess returns:** UNI return minus the average ETH/BTC return over the same window.
- **Conservative entries:** in the slow test, entry is +1h after forum posts and 11pm ET on release day for date-only sources. In the fast test, the entry price is the *open of the first 1-minute candle at or after* the entry time, never a price from before it.
- **Fees:** results are reported at 0.25%/side and 1.75%/side.
- **Lookahead bias:** the scoring model may remember older events. Claude was told not to use hindsight and asked to flag events it recognized (85 of 397), and the slow backtest supports an out-of-sample split by model training cutoff.
- **Data:** SEC and CFTC newsrooms, Federal Register API, Uniswap Discourse forum, Snapshot GraphQL, Coinbase public candles (hourly and 1-minute).

Full reports: [`docs/results/backtest_slow_report.md`](docs/results/backtest_slow_report.md), [`docs/results/backtest_fast_report.md`](docs/results/backtest_fast_report.md)

![Signal vs return](docs/images/signal_vs_return.png)

## Limitations

- Small samples: only 19 "buy" events in the fast test; one event dominates the result.
- SEC/CFTC releases only carry dates, so they couldn't be tested at minute resolution.
- A volatility score is not a direction call; the backtests showed direction is hard to predict.
- News sites can change their layouts or block automated readers.

## Next steps

- Deploy to a small cloud server so it runs 24/7 without my PC.
- After a few weeks, use `news_log.csv` to measure whether 8+ alerts actually preceded larger moves.
- Add faster sources (Telegram news channels) and calibrate the threshold.

---

## Project structure

```
market-news-alarm/
├── alarm/
│   └── market_news_alarm.py     # live 24/7 alarm
├── backtests/
│   ├── uni_news_backtest.py     # Test 1: daily-resolution, 4 sources, ~400 events
│   └── uni_fast_backtest.py     # Test 2: minute-resolution, fees, entry/exit grid
├── docs/
│   ├── images/                  # charts and screenshots
│   └── results/                 # full backtest reports
├── config.example.json
├── requirements.txt
└── README.md
```

## Running it

Requires Python 3.10+ and an [Anthropic API key](https://console.anthropic.com).

```bash
pip install -r requirements.txt
python alarm/market_news_alarm.py
```

On first run it asks for the API key and a contact email (the SEC requires one for automated access); both are stored locally in the project root and excluded by `.gitignore`. It then prints a private channel name to subscribe to in the free [ntfy](https://ntfy.sh) phone app and sends a test alert. Settings (threshold, polling interval, sources) are at the top of `alarm/market_news_alarm.py`.

To reproduce the backtests: `python backtests/uni_news_backtest.py`, then `python backtests/uni_fast_backtest.py`.

## Tech

Python · Anthropic Claude API (Haiku 4.5, Sonnet 5) · pandas · matplotlib · feedparser · REST/GraphQL APIs · ntfy

Built with Claude (Anthropic) as an AI pair-programmer.

*Not financial advice.*
