#!/usr/bin/env python3
"""
MARKET NEWS ALARM
=================
Watches government, financial and crypto news around the clock. Claude rates
every new item 1-10 for how much volatility it could cause in ANY market
(stock market, sectors like tech or banks, single companies, crypto, bonds,
oil, currencies). Your phone only buzzes when the rating is ABOVE 7.

HOW TO RUN: open this file in VS Code and press Run. Leave it running.
  - First run installs what it needs and asks for your Anthropic API key
    (saved in anthropic_key.txt in the project folder, which is never uploaded).
  - It then shows you a private channel name to enter in the free "ntfy"
    phone app, and sends a test alert so you know it works.
  - Every item it rates is saved to news_log.csv (useful for testing later).
Don't type anything into this file except the SETTINGS below, if you want.

Remember: a high score means "this could move markets", not "buy".
"""

import subprocess
import sys

# ---- auto-install libraries on first run ----
_NEEDED = {"anthropic": "anthropic", "requests": "requests", "feedparser": "feedparser"}
_missing = []
for _mod, _pkg in _NEEDED.items():
    try:
        __import__(_mod)
    except ImportError:
        _missing.append(_pkg)
if _missing:
    print("First run: installing", ", ".join(_missing), "...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", *_missing])
    except subprocess.CalledProcessError:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "--user", *_missing])

import csv
import html as htmllib
import json
import os
import re
import secrets
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

import feedparser
import requests

try:
    sys.stdout.reconfigure(errors="replace")
except Exception:
    pass

# =================================================================== SETTINGS
ALERT_ABOVE = 7          # alert only when Claude's rating is above this (so 8, 9, 10)
POLL_SECONDS = 60        # how often to check the news sources
QUICK_PASS = 6           # quick-read score needed before Claude does a full read
MAX_DEEP_PER_HOUR = 40   # safety cap on full reads (keeps API cost predictable)
FAST_MODEL = "claude-haiku-4-5-20251001"   # cheap quick read of every headline
DEEP_MODEL = "claude-sonnet-5"             # careful read of anything that might matter

SOURCES = [
    # --- US government / regulators
    {"name": "SEC", "type": "rss", "url": "https://www.sec.gov/news/pressreleases.rss"},
    {"name": "CFTC", "type": "html", "url": "https://www.cftc.gov/PressRoom/PressReleases",
     "pattern": r'href="(/PressRoom/PressReleases/\d+-\d{2})"[^>]*>(.*?)</a>',
     "base": "https://www.cftc.gov"},
    {"name": "Federal Reserve", "type": "rss", "url": "https://www.federalreserve.gov/feeds/press_all.xml"},
    {"name": "Federal Register", "type": "fedreg",
     "url": "https://www.federalregister.gov/api/v1/public-inspection-documents/current.json"},
    # --- markets news
    {"name": "CNBC", "type": "rss", "url": "https://www.cnbc.com/id/100003114/device/rss/rss.html"},
    {"name": "Yahoo Finance", "type": "rss", "url": "https://finance.yahoo.com/news/rssindex"},
    # --- crypto news
    {"name": "CoinDesk", "type": "rss", "url": "https://www.coindesk.com/arc/outboundfeeds/rss/"},
    {"name": "Cointelegraph", "type": "rss", "url": "https://cointelegraph.com/rss"},
]
# ============================================================================


# ---- private settings (config.json and secrets live in the project root, never uploaded) ----
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent if HERE.name in ("alarm", "backtests") else HERE
CONFIG_FILE = ROOT / "config.json"


def load_contact_email() -> str:
    """The SEC asks automated readers to identify themselves with a contact email."""
    if os.environ.get("CONTACT_EMAIL"):
        return os.environ["CONTACT_EMAIL"]
    try:
        cfg = json.loads(CONFIG_FILE.read_text())
    except Exception:
        cfg = {}
    if cfg.get("contact_email"):
        return cfg["contact_email"]
    print("The SEC asks automated readers to include a contact email.")
    email = input("Your email (saved privately in config.json, not uploaded to GitHub): ").strip()
    cfg["contact_email"] = email
    CONFIG_FILE.write_text(json.dumps(cfg, indent=2))
    return email


CONTACT_EMAIL = load_contact_email()
KEY_FILE = ROOT / "anthropic_key.txt"
TOPIC_FILE = ROOT / "ntfy_topic.txt"
STATE_FILE = HERE / "alarm_state.json"
LOG_FILE = HERE / "news_log.csv"
UA = {"User-Agent": f"Mozilla/5.0 (compatible; market-news-alarm/1.0; {CONTACT_EMAIL})"}


# ------------------------------------------------------------------ setup
def ensure_api_key():
    if os.environ.get("ANTHROPIC_API_KEY"):
        return
    if KEY_FILE.exists() and KEY_FILE.read_text().strip():
        os.environ["ANTHROPIC_API_KEY"] = KEY_FILE.read_text().strip()
        return
    print("Paste your Anthropic API key (starts with sk-ant-) and press Enter:")
    key = input("API key: ").strip().strip('"')
    if not key.startswith("sk-ant-"):
        sys.exit("That doesn't look like an API key. Press Run again and paste the full key.")
    KEY_FILE.write_text(key)
    os.environ["ANTHROPIC_API_KEY"] = key


def ensure_topic() -> str:
    if TOPIC_FILE.exists() and TOPIC_FILE.read_text().strip():
        return TOPIC_FILE.read_text().strip()
    topic = "market-alarm-" + secrets.token_hex(6)
    TOPIC_FILE.write_text(topic)
    return topic


def load_state():
    try:
        s = json.loads(STATE_FILE.read_text())
        return s.get("seen", []), s.get("recent_alerts", [])
    except Exception:
        return [], []


def save_state(seen_order, recent_alerts):
    STATE_FILE.write_text(json.dumps({"seen": seen_order[-30000:], "recent_alerts": recent_alerts}))


# ------------------------------------------------------------------ fetching
def strip_html(s: str) -> str:
    s = re.sub(r"(?is)<(script|style|noscript).*?</\1>", " ", s or "")
    s = re.sub(r"(?s)<[^>]+>", " ", s)
    return re.sub(r"\s+", " ", htmllib.unescape(s)).strip()


def fetch_source(src):
    r = requests.get(src["url"], headers=UA, timeout=25)
    r.raise_for_status()
    items = []
    if src["type"] == "rss":
        for e in feedparser.parse(r.content).entries[:60]:
            link = e.get("link", "")
            items.append({"id": f"{src['name']}|{e.get('id') or link or e.get('title')}",
                          "source": src["name"], "title": strip_html(e.get("title", "")),
                          "link": link, "summary": strip_html(e.get("summary", ""))[:600],
                          "published": e.get("published", "")})
    elif src["type"] == "html":
        for path, raw in re.findall(src["pattern"], r.text, re.S)[:40]:
            title = strip_html(raw)
            if len(title) > 8:
                items.append({"id": f"{src['name']}|{path}", "source": src["name"], "title": title,
                              "link": src["base"] + path, "summary": "", "published": ""})
    elif src["type"] == "fedreg":
        for d in r.json().get("results", []):
            agencies = d.get("agency_names") or [a.get("name", "") for a in d.get("agencies", []) or []]
            items.append({"id": f"FR|{d.get('document_number') or d.get('html_url')}",
                          "source": src["name"],
                          "title": f"{', '.join(a for a in agencies if a)[:80]}: {d.get('title', '')}",
                          "link": d.get("html_url", ""), "summary": d.get("type", "") or "",
                          "published": d.get("filed_at", "") or ""})
    return [i for i in items if i["title"]]


_fail_streak = {}
def fetch_all():
    out, health = [], {}
    for src in SOURCES:
        try:
            got = fetch_source(src)
            out += got
            health[src["name"]] = len(got)
            if _fail_streak.get(src["name"], 0) >= 3:
                print(f"   {src['name']} is working again")
            _fail_streak[src["name"]] = 0
        except Exception as e:
            n = _fail_streak.get(src["name"], 0) + 1
            _fail_streak[src["name"]] = n
            health[src["name"]] = f"FAILED ({str(e)[:60]})"
            if n == 3:
                print(f"   ! {src['name']} keeps failing ({str(e)[:80]}); will keep retrying quietly")
    return out, health


def page_text(url: str) -> str:
    try:
        r = requests.get(url, headers=UA, timeout=20)
        r.raise_for_status()
        return strip_html(r.text)[:12000]
    except Exception:
        return ""


# ------------------------------------------------------------------ Claude
_client = None
def claude_json(model, prompt, max_tokens=800):
    global _client
    if _client is None:
        import anthropic
        _client = anthropic.Anthropic()
    for i in range(3):
        try:
            msg = _client.messages.create(model=model, max_tokens=max_tokens,
                                          messages=[{"role": "user", "content": prompt}])
            txt = "".join(b.text for b in msg.content if b.type == "text")
            return json.loads(re.search(r"\{.*\}", txt, re.S).group(0))
        except Exception as e:
            print(f"   ! Claude error ({str(e)[:80]}); retrying")
            time.sleep(2 ** i)
    return None


def quick_scores(items):
    scores = {}
    for i in range(0, len(items), 30):
        batch = items[i:i + 30]
        lines = "\n".join(f"{k}. [{it['source']}] {it['title']} -- {it['summary'][:150]}"
                          for k, it in enumerate(batch))
        res = claude_json(FAST_MODEL, f"""You screen news headlines for a trader who wants to know
about anything that could cause a significant price move in ANY market: the overall stock market,
a sector (tech, banks, energy, defense, pharma...), a single large company, crypto, bonds,
currencies or commodities. Give each headline a quick 1-10 guess of its potential to cause
market volatility. Most news is 1-3. Routine filings, opinion pieces and price recaps are 1-2.

{lines}

Reply with ONLY JSON like {{"scores": {{"0": 2, "1": 7}}}}""", max_tokens=600)
        got = (res or {}).get("scores", {})
        for k, it in enumerate(batch):
            try:
                scores[it["id"]] = int(got.get(str(k), 0))
            except (TypeError, ValueError):
                scores[it["id"]] = 0
    return scores


DEEP_PROMPT = """You are a market analyst deciding whether to wake up a trader. Right now it is
{now}. A new item just appeared.

SOURCE: {source}
TITLE: {title}
SUMMARY: {summary}
PAGE TEXT (may be partial): {text}

Alerts already sent in the last 48 hours (don't re-alert the same story):
{recent}

Rate from 1-10 how much VOLATILITY this could cause in any market, judged by what is NEW here,
not by how important the topic is in general. Scale:
 10  historic shock: surprise emergency Fed move, major war outbreak, collapse of a major bank or exchange
 8-9 major surprise for a whole sector or big asset: unexpected Fed decision, sweeping export ban on
     chips or a key technology, surprise approval/rejection of a major crypto ETF, huge hack of a
     top crypto protocol, landmark ruling or enforcement against a mega-cap company
 7   significant new policy or event likely to move a sector or asset several percent
     (e.g. an SEC exemption that opens tokenized stock trading on crypto platforms)
 5-6 notable but narrow, partly expected, or slow-acting
 3-4 routine rules, small enforcement cases, minor company news
 1-2 administrative, recaps, opinion
Lower the score if the news was scheduled/expected, already widely reported, or only a follow-up.

Reply with ONLY JSON:
{{"score": <1-10>,
  "headline": "<max 12 words, plain English>",
  "markets": [{{"market": "<e.g. Tech stocks - quantum computing>", "direction": "up|down|big move either way",
               "examples": "<a few tickers or coins, or empty>"}}],
  "novelty": "new|expected|follow-up",
  "same_story_as_recent_alert": <true|false>,
  "why": "<2 short sentences: what happened and why it could move those markets>"}}"""


def deep_score(item, recent_alerts):
    recent = "\n".join(f"- {a['headline']}" for a in recent_alerts) or "(none)"
    text = page_text(item["link"]) if item["link"] else ""
    return claude_json(DEEP_MODEL, DEEP_PROMPT.format(
        now=datetime.now().astimezone().strftime("%Y-%m-%d %H:%M %Z"),
        source=item["source"], title=item["title"], summary=item["summary"] or "(none)",
        text=text or "(could not load page)", recent=recent), max_tokens=900)


# ------------------------------------------------------------------ alerts + log
def notify(topic, title, message, link="", priority=4):
    try:
        requests.post("https://ntfy.sh/", timeout=15, json={
            "topic": topic, "title": title[:250], "message": message[:3500],
            "priority": priority, "tags": ["rotating_light"], **({"click": link} if link else {})})
        return True
    except Exception as e:
        print(f"   ! could not send phone alert ({e})")
        return False


def format_alert(item, d):
    markets = "\n".join(
        f"- {m.get('market', '')}: {m.get('direction', '')}"
        + (f" ({m['examples']})" if m.get("examples") else "")
        for m in d.get("markets", []))
    return (f"{d.get('why', '')}\n\nCould move:\n{markets}\n\n"
            f"Novelty: {d.get('novelty', '?')} | Source: {item['source']}\n"
            "A high score means volatility, not a buy signal.")


LOG_COLS = ["detected_at", "source", "title", "link", "published", "quick", "score",
            "novelty", "same_story", "markets", "why", "alerted"]
def log_rows(rows):
    new_file = not LOG_FILE.exists()
    try:
        with LOG_FILE.open("a", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=LOG_COLS)
            if new_file:
                w.writeheader()
            w.writerows(rows)
    except PermissionError:
        print("   ! news_log.csv is open in another program (Excel?). Close it so logging continues.")


# ------------------------------------------------------------------ main loop
def process(new_items, topic, recent_alerts, deep_times):
    quick = quick_scores(new_items)
    rows, alerts = [], 0
    now = datetime.now(timezone.utc)
    for it in new_items:
        row = {"detected_at": now.isoformat(timespec="seconds"), "source": it["source"],
               "title": it["title"], "link": it["link"], "published": it["published"],
               "quick": quick.get(it["id"], 0), "score": "", "novelty": "", "same_story": "",
               "markets": "", "why": "", "alerted": False}
        if row["quick"] >= QUICK_PASS:
            deep_times[:] = [t for t in deep_times if t > time.time() - 3600]
            if len(deep_times) >= MAX_DEEP_PER_HOUR:
                print("   (hourly cap on full reads reached; skipping)")
            else:
                deep_times.append(time.time())
                d = deep_score(it, recent_alerts)
                if d:
                    score = int(d.get("score", 0) or 0)
                    dup = bool(d.get("same_story_as_recent_alert"))
                    row.update(score=score, novelty=d.get("novelty", ""), same_story=dup,
                               markets="; ".join(m.get("market", "") for m in d.get("markets", [])),
                               why=d.get("why", ""))
                    print(f"   [{score}/10] {it['source']}: {it['title'][:80]}")
                    if score > ALERT_ABOVE and not dup:
                        prio = 5 if score >= 9 else 4
                        if notify(topic, f"[{score}/10] {d.get('headline', it['title'])}",
                                  format_alert(it, d), it["link"], prio):
                            row["alerted"] = True
                            alerts += 1
                            recent_alerts.append({"time": now.isoformat(), "headline": d.get("headline", it["title"])})
                            print("      >>> ALERT SENT TO YOUR PHONE")
        rows.append(row)
    log_rows(rows)
    return alerts


def main():
    ensure_api_key()
    topic = ensure_topic()
    seen_order, recent_alerts = load_state()
    seen = set(seen_order)
    first_run = not seen

    print("=" * 64)
    print(" MARKET NEWS ALARM")
    print(f" Alerts when Claude rates news above {ALERT_ABOVE}/10. Checking every {POLL_SECONDS}s.")
    print("=" * 64)
    print("\nGET ALERTS ON YOUR PHONE:")
    print("  1. Install the free app 'ntfy' (App Store / Google Play)")
    print("  2. Tap + (subscribe to topic) and enter exactly:")
    print(f"\n        {topic}\n")
    print("  Keep this name private: anyone with it can see your alerts.\n")
    notify(topic, "Market alarm is running", f"Watching {len(SOURCES)} news sources. "
           f"You'll be alerted when news rates above {ALERT_ABOVE}/10.", priority=3)

    items, health = fetch_all()
    print("Source check:")
    for name, h in health.items():
        print(f"  {'OK  ' if isinstance(h, int) else 'FAIL'} {name}: {h if not isinstance(h, int) else str(h) + ' items'}")

    deep_times = []
    if first_run:
        for it in items:
            if it["id"] not in seen:
                seen.add(it["id"])
                seen_order.append(it["id"])
        print(f"\nFirst run: {len(items)} existing items marked as already seen.")
        sample = next((i for i in items if i["source"] == "SEC"), items[0] if items else None)
        if sample:
            print(f"Sending a TEST alert by rating: {sample['title'][:70]}")
            d = deep_score(sample, [])
            if d:
                notify(topic, f"[TEST {d.get('score', '?')}/10] {d.get('headline', sample['title'])}",
                       "This is a test so you can see what alerts look like.\n\n" + format_alert(sample, d),
                       sample["link"], 3)
                print(f"   test rated {d.get('score')}/10 and sent to your phone")
        save_state(seen_order, recent_alerts)

    print("\nWatching for NEW items. Leave this window open (and the PC awake). Ctrl+C to stop.\n")
    last_beat = time.time()
    while True:
        time.sleep(POLL_SECONDS)
        try:
            items, _ = fetch_all()
            new = [i for i in items if i["id"] not in seen]
            for i in new:
                seen.add(i["id"])
                seen_order.append(i["id"])
            cutoff = (datetime.now(timezone.utc) - timedelta(hours=48)).isoformat()
            recent_alerts[:] = [a for a in recent_alerts if a["time"] > cutoff]
            if new:
                stamp = datetime.now().strftime("%H:%M")
                print(f"[{stamp}] {len(new)} new item(s)")
                process(new, topic, recent_alerts, deep_times)
            elif time.time() - last_beat > 900:
                print(f"[{datetime.now().strftime('%H:%M')}] still watching, nothing new")
                last_beat = time.time()
            save_state(seen_order, recent_alerts)
        except KeyboardInterrupt:
            raise
        except Exception as e:
            print(f"   ! unexpected error ({e}); continuing")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nStopped.")
